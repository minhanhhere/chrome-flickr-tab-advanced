# Flickr Tab Advanced

1. <a href="https://github.com/minhanhhere/chrome-flickr-tab-advanced/raw/master/chrome-flick-tab-advanced.zip" target="_blank">Download</a> & unzip the extension

2. Open the Google Chrome browser and type the following in the address bar:
> chrome://extensions

3. Enable the Developer mode option on the top right corner of the extensions page. The buttons "Load unpacked extension" and "Pack extension" will appear on the screen.
>![Enable developer mode](http://winaero.com/blog/wp-content/uploads/2014/05/developer-mode-enabled-600x464.png "")

4. Click the Load unpacked extension button and point the browser to the unpacked extension folder.
>![Load unpacked extension](http://winaero.com/blog/wp-content/uploads/2014/05/unpacked-extension-folder-600x466.png "")
